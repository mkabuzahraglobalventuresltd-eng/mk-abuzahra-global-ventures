-- MK Abuzahra Global Ventures Ltd
-- COMPLETE MULTI-PRODUCT SALE CLAIM UPDATE
-- Adds multiple products per customer/order, full delivery address, verification details,
-- and keeps the one-time authenticator workflow.
-- Run once in Supabase SQL Editor.

begin;

create extension if not exists pgcrypto;

alter table public.mk_sales
  add column if not exists full_delivery_address text,
  add column if not exists city text,
  add column if not exists state text,
  add column if not exists landmark text,
  add column if not exists order_total numeric(14,2) not null default 0;

update public.mk_sales
set order_total = total_amount
where order_total = 0 and total_amount is not null;

create table if not exists public.mk_sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_uuid uuid not null references public.mk_sales(id) on delete cascade,
  product_id uuid not null references public.mk_products(id),
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  subtotal numeric(14,2) generated always as (quantity * unit_price) stored,
  created_at timestamptz not null default now()
);

create index if not exists mk_sale_items_sale_uuid_idx on public.mk_sale_items(sale_uuid);
create index if not exists mk_sales_advertiser_id_idx on public.mk_sales(advertiser_id);

-- Explicit casts make pgcrypto digest resolution unambiguous.
create or replace function public.mk_hash_claim_code(p_code text)
returns text
language sql
immutable
set search_path = public, extensions
as $$
  select encode(digest(p_code::text, 'sha256'::text), 'hex');
$$;

revoke execute on function public.mk_hash_claim_code(text) from public;

-- New multi-product claim RPC.
drop function if exists public.mk_create_sale_claim(uuid,text,text,uuid,integer,numeric,text,text,numeric,date);
drop function if exists public.mk_create_sale_claim(uuid,text,text,uuid,integer,numeric,text,text,text,text,text,text,numeric,date);

create or replace function public.mk_create_sale_claim(
  p_advertiser_id uuid,
  p_customer_name text,
  p_customer_phone text,
  p_items jsonb,
  p_customer_location text,
  p_full_delivery_address text,
  p_city text,
  p_state text,
  p_landmark text,
  p_payment_status text,
  p_amount_paid numeric,
  p_expected_collection_date date
) returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  uid uuid := auth.uid();
  aid uuid := coalesce(p_advertiser_id, uid);
  item jsonb;
  pr public.mk_products%rowtype;
  s public.mk_sales%rowtype;
  code text;
  sid text;
  rate numeric := 0;
  hours integer := 48;
  exp timestamptz;
  total numeric := 0;
  item_count integer := 0;
  first_product_id uuid;
  first_product_name text;
  first_qty integer;
  first_price numeric;
begin
  if not public.mk_is_admin()
     and not (uid = aid and exists(
       select 1 from public.profiles
       where id = uid and role = 'advertiser' and status = 'active'
     )) then
    raise exception 'Not authorized';
  end if;

  if not exists(select 1 from public.profiles where id=aid and role='advertiser' and status='active') then
    raise exception 'Advertiser is not active';
  end if;

  if nullif(trim(p_customer_name),'') is null then raise exception 'Customer name is required'; end if;
  if nullif(trim(p_customer_phone),'') is null then raise exception 'Customer phone is required'; end if;
  if nullif(trim(p_full_delivery_address),'') is null then raise exception 'Full delivery address is required'; end if;
  if nullif(trim(p_city),'') is null then raise exception 'City/Town is required'; end if;
  if nullif(trim(p_state),'') is null then raise exception 'State is required'; end if;
  if nullif(trim(p_customer_location),'') is null then raise exception 'Customer location is required'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 then
    raise exception 'At least one product is required';
  end if;
  if p_payment_status not in ('UNPAID','PARTIAL','PAID') then raise exception 'Invalid payment status'; end if;
  if p_amount_paid is null or p_amount_paid < 0 then raise exception 'Invalid amount paid'; end if;

  for item in select * from jsonb_array_elements(p_items) loop
    if nullif(item->>'product_id','') is null then raise exception 'Every item needs a product'; end if;
    select * into pr from public.mk_products where id=(item->>'product_id')::uuid and active=true;
    if not found then raise exception 'One of the selected products is inactive or missing'; end if;
    if coalesce((item->>'quantity')::integer,0) < 1 then raise exception 'Quantity must be at least 1'; end if;
    if coalesce((item->>'unit_price')::numeric,-1) < 0 then raise exception 'Unit price cannot be negative'; end if;

    if item_count = 0 then
      first_product_id := pr.id;
      first_product_name := pr.name;
      first_qty := (item->>'quantity')::integer;
      first_price := (item->>'unit_price')::numeric;
    end if;

    total := total + ((item->>'quantity')::numeric * (item->>'unit_price')::numeric);
    item_count := item_count + 1;
  end loop;

  if p_amount_paid > total then raise exception 'Amount paid cannot exceed order total'; end if;
  if p_payment_status='PAID' and p_amount_paid < total then raise exception 'Paid status requires full payment'; end if;
  if p_payment_status='UNPAID' and p_amount_paid <> 0 then raise exception 'Unpaid status cannot have amount paid'; end if;
  if p_payment_status='PARTIAL' and (p_amount_paid <= 0 or p_amount_paid >= total) then raise exception 'Partial payment must be greater than 0 and less than total'; end if;

  select commission_rate, claim_validity_hours into rate, hours from public.mk_settings where id=true;
  sid := 'SALE-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.mk_sale_seq')::text,5,'0');

  insert into public.mk_sales(
    sale_id, advertiser_id, customer_name, customer_phone, customer_location,
    full_delivery_address, city, state, landmark,
    product_id, product_name, quantity, unit_price,
    payment_status, amount_paid, expected_collection_date, order_total
  ) values (
    sid, aid, trim(p_customer_name), trim(p_customer_phone), trim(p_customer_location),
    trim(p_full_delivery_address), trim(p_city), trim(p_state), nullif(trim(p_landmark),''),
    first_product_id, first_product_name, first_qty, first_price,
    p_payment_status, p_amount_paid, p_expected_collection_date, total
  ) returning * into s;

  for item in select * from jsonb_array_elements(p_items) loop
    select * into pr from public.mk_products where id=(item->>'product_id')::uuid and active=true;
    insert into public.mk_sale_items(sale_uuid,product_id,product_name,quantity,unit_price)
    values(s.id,pr.id,pr.name,(item->>'quantity')::integer,(item->>'unit_price')::numeric);
  end loop;

  code := lpad((floor(random()*900000)+100000)::int::text,6,'0');
  exp := now() + (hours || ' hours')::interval;

  insert into public.mk_authenticators(sale_uuid,code_hash,expires_at)
  values(s.id,public.mk_hash_claim_code(code),exp);

  insert into public.mk_commissions(sale_uuid,advertiser_id,rate,amount)
  values(s.id,aid,rate,round(total*rate/100,2));

  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_CLAIM_CREATED','sale',s.id::text,jsonb_build_object(
    'sale_id',sid,'advertiser_id',aid,'customer_name',s.customer_name,
    'item_count',item_count,'order_total',total,'city',s.city,'state',s.state
  ));

  return jsonb_build_object(
    'sale_id',s.sale_id,
    'authenticator_code',code,
    'total_amount',total,
    'item_count',item_count,
    'claim_expires_at',exp
  );
end;
$$;

grant execute on function public.mk_create_sale_claim(uuid,text,text,jsonb,text,text,text,text,text,text,numeric,date) to authenticated;

-- Verification now returns the full order and all products.
create or replace function public.mk_verify_sale_claim(p_code text,p_customer_phone text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  a public.mk_authenticators%rowtype;
  s public.mk_sales%rowtype;
  advertiser_name text;
  items jsonb;
begin
  if not public.mk_is_admin() then raise exception 'Only staff/admin can verify claims'; end if;

  select * into a
  from public.mk_authenticators
  where code_hash=public.mk_hash_claim_code(trim(p_code)) and used_at is null
  for update;

  if not found or a.expires_at < now() then raise exception 'Invalid, expired, or used code'; end if;

  select * into s from public.mk_sales where id=a.sale_uuid for update;
  if s.status <> 'claimed' then raise exception 'This claim has already been verified, redeemed, or closed'; end if;

  if regexp_replace(s.customer_phone,'\D','','g') <> regexp_replace(trim(p_customer_phone),'\D','','g') then
    raise exception 'Customer phone does not match';
  end if;

  select full_name into advertiser_name from public.profiles where id=s.advertiser_id;
  select coalesce(jsonb_agg(jsonb_build_object(
    'product_id',i.product_id,
    'product_name',i.product_name,
    'quantity',i.quantity,
    'unit_price',i.unit_price,
    'subtotal',i.subtotal
  ) order by i.created_at),'[]'::jsonb) into items
  from public.mk_sale_items i where i.sale_uuid=s.id;

  update public.mk_sales
  set status='verified',verified_at=now(),verified_by=auth.uid()
  where id=s.id;

  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_CLAIM_VERIFIED','sale',s.id::text,jsonb_build_object('sale_id',s.sale_id));

  return jsonb_build_object(
    'sale_id',s.sale_id,
    'advertiser_id',s.advertiser_id,
    'advertiser_name',advertiser_name,
    'customer_name',s.customer_name,
    'customer_phone',s.customer_phone,
    'full_delivery_address',s.full_delivery_address,
    'city',s.city,
    'state',s.state,
    'landmark',s.landmark,
    'customer_location',s.customer_location,
    'items',items,
    'total_amount',s.order_total,
    'amount_paid',s.amount_paid,
    'balance',greatest(s.order_total-s.amount_paid,0),
    'payment_status',s.payment_status,
    'expected_collection_date',s.expected_collection_date,
    'status','verified'
  );
end;
$$;

grant execute on function public.mk_verify_sale_claim(text,text) to authenticated;

-- Redemption/commission must use the multi-item order total.
create or replace function public.mk_redeem_sale(p_sale_id text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  s public.mk_sales%rowtype;
  c public.mk_commissions%rowtype;
  allow_partial boolean;
begin
  if not public.mk_is_admin() then raise exception 'Only staff/admin can redeem'; end if;
  select * into s from public.mk_sales where sale_id=p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;
  if s.status<>'verified' then raise exception 'Sale must be verified first'; end if;
  select allow_partial_redeem into allow_partial from public.mk_settings where id=true;
  if s.payment_status='UNPAID' then raise exception 'Payment must be confirmed before redemption'; end if;
  if s.payment_status='PARTIAL' and not allow_partial then raise exception 'Partial payment is not allowed for redemption'; end if;

  update public.mk_sales set status='redeemed',redeemed_at=now(),redeemed_by=auth.uid() where id=s.id;
  update public.mk_authenticators set used_at=now() where sale_uuid=s.id;
  select * into c from public.mk_commissions where sale_uuid=s.id;

  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_REDEEMED','sale',s.id::text,jsonb_build_object('sale_id',s.sale_id,'order_total',s.order_total,'commission',c.amount));

  return jsonb_build_object('sale_id',s.sale_id,'order_total',s.order_total,'commission_amount',c.amount);
end;
$$;

grant execute on function public.mk_redeem_sale(text) to authenticated;

alter table public.mk_sale_items enable row level security;

drop policy if exists mk_sale_items_read on public.mk_sale_items;
create policy mk_sale_items_read on public.mk_sale_items
for select to authenticated
using (
  exists (
    select 1 from public.mk_sales s
    where s.id=mk_sale_items.sale_uuid
      and (s.advertiser_id=auth.uid() or public.mk_is_admin())
  )
);

revoke all on table public.mk_sale_items from anon;
grant select on table public.mk_sale_items to authenticated;

commit;

-- OPTIONAL PRODUCT POLICY:
-- No specific product (including Yarwa) is required or inserted as a default.
-- A claim only requires at least one selected active product item.
