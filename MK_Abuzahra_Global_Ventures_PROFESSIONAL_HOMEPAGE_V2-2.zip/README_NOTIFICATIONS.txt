MK ABUZAHRA GLOBAL VENTURES LTD
ADVERTISER NOTIFICATIONS UPDATE

1. Open Supabase -> SQL Editor -> New query.
2. Open ADVERTISER_NOTIFICATIONS_SETUP.sql from this package.
3. Copy ALL of its contents into Supabase SQL Editor.
4. Click RUN.
5. You should get a successful result. The SQL is written for the current schema where mk_advertiser_details.id is the same advertiser/profile UUID. It does NOT use a profile_id column.
6. Upload/replace the website files in your GitHub Pages repository with the files in this package. Keep assets/logo.png.

FEATURES
- Advertiser portal notification bell 🔔
- Unread notification count
- Mark one as read / mark all as read
- Super Admin -> Notifications panel
- Send to all active advertisers or one advertiser
- Notification type and priority
- Automatic notifications for advertiser approval/suspension/rejection
- Automatic notifications for sale claim creation/verification/redemption/cancellation/expiry
- Automatic notifications for commission recorded/eligible/paid
- Audit log for Super Admin-sent notifications

IMPORTANT
- Do not run the old SQL that used mk_advertiser_details.profile_id.
- This setup does not require a profile_id column.
- This update does not remove your existing sales, products, advertisers, commissions, or settings.
