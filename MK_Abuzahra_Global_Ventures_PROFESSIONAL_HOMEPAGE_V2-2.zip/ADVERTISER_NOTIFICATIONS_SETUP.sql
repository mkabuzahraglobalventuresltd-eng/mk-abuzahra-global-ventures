-- MK Abuzahra Global Ventures Ltd
-- Advertiser Notifications System
-- IMPORTANT: This version matches the current schema where
-- public.mk_advertiser_details.id = public.profiles.id.
-- No profile_id column is required.

begin;

create table if not exists public.mk_notifications (
  id uuid primary key default gen_random_uuid(),
  advertiser_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  notification_type text not null default 'announcement'
    check (notification_type in ('announcement','sale','commission','order','delivery','account','warning','system')),
  priority text not null default 'normal'
    check (priority in ('low','normal','high','urgent')),
  is_read boolean not null default false,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create index if not exists idx_mk_notifications_advertiser_created
  on public.mk_notifications(advertiser_id, created_at desc);
create index if not exists idx_mk_notifications_unread
  on public.mk_notifications(advertiser_id, is_read, created_at desc);

alter table public.mk_notifications enable row level security;

drop policy if exists mk_notifications_select on public.mk_notifications;
create policy mk_notifications_select
on public.mk_notifications for select to authenticated
using (advertiser_id = auth.uid() or public.mk_is_admin());

drop policy if exists mk_notifications_update on public.mk_notifications;
create policy mk_notifications_update
on public.mk_notifications for update to authenticated
using (advertiser_id = auth.uid() or public.mk_is_admin())
with check (advertiser_id = auth.uid() or public.mk_is_admin());

-- Mark one notification as read.
create or replace function public.mk_mark_notification_read(p_notification_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.mk_notifications
  set is_read = true, read_at = coalesce(read_at, now())
  where id = p_notification_id
    and (advertiser_id = auth.uid() or public.mk_is_admin());

  if not found then
    raise exception 'Notification not found or not authorized';
  end if;

  return jsonb_build_object('ok', true, 'id', p_notification_id);
end;
$$;
grant execute on function public.mk_mark_notification_read(uuid) to authenticated;

-- Mark all notifications belonging to the current advertiser as read.
create or replace function public.mk_mark_all_notifications_read()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare n integer;
begin
  update public.mk_notifications
  set is_read = true, read_at = coalesce(read_at, now())
  where advertiser_id = auth.uid() and is_read = false;
  get diagnostics n = row_count;
  return jsonb_build_object('ok', true, 'marked', n);
end;
$$;
grant execute on function public.mk_mark_all_notifications_read() to authenticated;

-- Super Admin sends a notification to one advertiser or every active advertiser.
-- p_advertiser_id = NULL means ALL ACTIVE ADVERTISERS.
create or replace function public.mk_send_notification(
  p_advertiser_id uuid,
  p_title text,
  p_message text,
  p_type text default 'announcement',
  p_priority text default 'normal'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  n integer;
  t text := lower(trim(coalesce(p_type,'announcement')));
  pr text := lower(trim(coalesce(p_priority,'normal')));
begin
  if not public.mk_is_super_admin() then
    raise exception 'Only Super Admin can send notifications';
  end if;
  if nullif(trim(p_title),'') is null then raise exception 'Notification title is required'; end if;
  if nullif(trim(p_message),'') is null then raise exception 'Notification message is required'; end if;
  if t not in ('announcement','sale','commission','order','delivery','account','warning','system') then
    raise exception 'Invalid notification type';
  end if;
  if pr not in ('low','normal','high','urgent') then raise exception 'Invalid notification priority'; end if;

  if p_advertiser_id is null then
    insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
    select id, trim(p_title), trim(p_message), t, pr
    from public.profiles
    where role='advertiser' and status='active';
  else
    if not exists(select 1 from public.profiles where id=p_advertiser_id and role='advertiser') then
      raise exception 'Advertiser not found';
    end if;
    insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
    values(p_advertiser_id,trim(p_title),trim(p_message),t,pr);
  end if;

  get diagnostics n = row_count;
  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'NOTIFICATION_SENT','notification',null,
    jsonb_build_object('recipient',p_advertiser_id,'count',n,'title',trim(p_title),'type',t,'priority',pr));

  return jsonb_build_object('ok',true,'sent',n);
end;
$$;
grant execute on function public.mk_send_notification(uuid,text,text,text,text) to authenticated;

-- Automatic notification when an advertiser account status changes.
create or replace function public.mk_notify_advertiser_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare title text; body text; pr text := 'normal';
begin
  if new.role='advertiser' and old.status is distinct from new.status then
    if new.status='active' then
      title := 'Advertiser Account Approved';
      body := 'Your advertiser account has been approved. You can now create Sale Claims.';
      pr := 'high';
    elsif new.status='suspended' then
      title := 'Advertiser Account Suspended';
      body := 'Your advertiser account has been suspended. Please contact the company for assistance.';
      pr := 'urgent';
    elsif new.status='rejected' then
      title := 'Advertiser Registration Rejected';
      body := coalesce(nullif(new.approval_note,''),'Your advertiser registration was rejected by the Super Admin.');
      pr := 'high';
    elsif new.status='pending' then
      title := 'Registration Pending';
      body := 'Your advertiser registration is pending Super Admin approval.';
    else
      return new;
    end if;

    insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
    values(new.id,title,body,'account',pr);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_mk_notify_advertiser_status on public.profiles;
create trigger trg_mk_notify_advertiser_status
after update of status on public.profiles
for each row execute function public.mk_notify_advertiser_status();

-- Automatic notification for important sale lifecycle changes.
create or replace function public.mk_notify_sale_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare title text; body text; typ text := 'sale'; pr text := 'normal'; total numeric;
begin
  total := coalesce(new.total_amount,0);
  if tg_op='INSERT' then
    title := 'Sale Claim Created';
    body := format('Sale %s for %s has been recorded. The one-time customer authenticator is active.', new.sale_id, new.customer_name);
    insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
    values(new.advertiser_id,title,body,'sale',pr);
  elsif old.status is distinct from new.status then
    if new.status='verified' then
      title := 'Sale Claim Verified';
      body := format('Sale %s for %s has been verified by company staff.', new.sale_id, new.customer_name);
      pr := 'high';
    elsif new.status='redeemed' then
      title := 'Order Completed';
      body := format('Sale %s has been redeemed/completed. Order value: ₦%s.', new.sale_id, to_char(total,'FM999,999,990.00'));
      pr := 'high';
    elsif new.status='cancelled' then
      title := 'Sale Claim Cancelled';
      body := format('Sale %s has been cancelled.', new.sale_id);
      pr := 'high';
    elsif new.status='expired' then
      title := 'Sale Claim Expired';
      body := format('Sale %s has expired. A new claim may be required.', new.sale_id);
      pr := 'high';
    else
      return new;
    end if;
    insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
    values(new.advertiser_id,title,body,'sale',pr);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_mk_notify_sale_change on public.mk_sales;
create trigger trg_mk_notify_sale_change
after insert or update of status on public.mk_sales
for each row execute function public.mk_notify_sale_change();

-- Automatic notification for commission lifecycle changes.
create or replace function public.mk_notify_commission_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare title text; body text; pr text := 'normal';
begin
  if tg_op='INSERT' then
    title := 'Commission Recorded';
    body := format('A commission of ₦%s has been recorded for your sale.', to_char(coalesce(new.amount,0),'FM999,999,990.00'));
  elsif old.status is distinct from new.status then
    if new.status='ELIGIBLE' then
      title := 'Commission Eligible';
      body := format('Your commission of ₦%s is now eligible for payment.', to_char(coalesce(new.amount,0),'FM999,999,990.00'));
      pr := 'high';
    elsif new.status='PAID' then
      title := 'Commission Paid';
      body := format('Your commission of ₦%s has been marked as paid.', to_char(coalesce(new.amount,0),'FM999,999,990.00'));
      pr := 'high';
    else
      return new;
    end if;
  else
    return new;
  end if;

  insert into public.mk_notifications(advertiser_id,title,message,notification_type,priority)
  values(new.advertiser_id,title,body,'commission',pr);
  return new;
end;
$$;

drop trigger if exists trg_mk_notify_commission_change on public.mk_commissions;
create trigger trg_mk_notify_commission_change
after insert or update of status on public.mk_commissions
for each row execute function public.mk_notify_commission_change();

commit;
