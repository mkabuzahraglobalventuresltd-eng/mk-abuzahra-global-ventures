-- MK Abuzahra Global Ventures Ltd: trusted pricing + minimum delivery rule
-- Additive migration. Run AFTER FINAL_SYSTEM.sql and multi_item_sale_claim_update.sql.
-- This migration does not implement payment gateways or commission-wallet changes.
begin;

do $$ begin
  if to_regclass('public.mk_products') is null or to_regclass('public.mk_sales') is null or to_regclass('public.mk_settings') is null or to_regclass('public.mk_sale_items') is null then
    raise exception 'Required MK tables are missing. Confirm FINAL_SYSTEM.sql and multi_item_sale_claim_update.sql were applied first.';
  end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='mk_products' and column_name='default_price') then
    raise exception 'mk_products.default_price is missing; migration stopped safely.';
  end if;
end $$;

alter table public.mk_settings add column if not exists minimum_delivery_order_amount numeric(14,2) not null default 10000;
alter table public.mk_sales add column if not exists fulfillment_method text not null default 'OFFICE_COLLECTION';

do $$ begin
  if not exists (select 1 from pg_constraint where conname='mk_sales_fulfillment_method_check' and conrelid='public.mk_sales'::regclass) then
    alter table public.mk_sales add constraint mk_sales_fulfillment_method_check check (fulfillment_method in ('OFFICE_COLLECTION','DELIVERY'));
  end if;
end $$;

revoke execute on function public.mk_create_sale_claim(uuid,text,text,jsonb,text,text,text,text,text,text,numeric,date) from public, anon, authenticated;
drop function if exists public.mk_create_sale_claim(uuid,text,text,jsonb,text,text,text,text,text,text,numeric,date);

create or replace function public.mk_create_sale_claim(
  p_advertiser_id uuid,
  p_customer_name text,
  p_customer_phone text,
  p_items jsonb,
  p_customer_location text,
  p_full_delivery_address text,
  p_city text,
  p_state text,
  p_landmark text,
  p_fulfillment_method text,
  p_payment_status text,
  p_amount_paid numeric,
  p_expected_collection_date date
) returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  uid uuid := auth.uid();
  aid uuid := coalesce(p_advertiser_id, uid);
  item jsonb;
  pr public.mk_products%rowtype;
  s public.mk_sales%rowtype;
  code text;
  sid text;
  rate numeric := 0;
  hours integer := 48;
  exp timestamptz;
  total numeric := 0;
  minimum_delivery numeric := 10000;
  chosen_fulfillment text := upper(coalesce(nullif(trim(p_fulfillment_method),''),'OFFICE_COLLECTION'));
  item_count integer := 0;
  first_product_id uuid;
  first_product_name text;
  first_qty integer;
  first_price numeric;
begin
  if not public.mk_is_admin()
     and not (uid = aid and exists(
       select 1 from public.profiles
       where id = uid and role = 'advertiser' and status = 'active'
     )) then
    raise exception 'Not authorized';
  end if;

  if not exists(select 1 from public.profiles where id=aid and role='advertiser' and status='active') then
    raise exception 'Advertiser is not active';
  end if;

  if nullif(trim(p_customer_name),'') is null then raise exception 'Customer name is required'; end if;
  if nullif(trim(p_customer_phone),'') is null then raise exception 'Customer phone is required'; end if;
  if nullif(trim(p_full_delivery_address),'') is null then raise exception 'Full delivery address is required'; end if;
  if nullif(trim(p_city),'') is null then raise exception 'City/Town is required'; end if;
  if nullif(trim(p_state),'') is null then raise exception 'State is required'; end if;
  if nullif(trim(p_customer_location),'') is null then raise exception 'Customer location is required'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 then
    raise exception 'At least one product is required';
  end if;
  if p_payment_status not in ('UNPAID','PARTIAL','PAID') then raise exception 'Invalid payment status'; end if;
  if p_amount_paid is null or p_amount_paid < 0 then raise exception 'Invalid amount paid'; end if;

  for item in select * from jsonb_array_elements(p_items) loop
    if nullif(item->>'product_id','') is null then raise exception 'Every item needs a product'; end if;
    select * into pr from public.mk_products where id=(item->>'product_id')::uuid and active=true;
    if not found then raise exception 'One of the selected products is inactive or missing'; end if;
    if pr.default_price is null or pr.default_price < 0 then raise exception 'Selected product has an invalid company price'; end if;
    if coalesce((item->>'quantity')::integer,0) < 1 then raise exception 'Quantity must be at least 1'; end if;

    if item_count = 0 then
      first_product_id := pr.id;
      first_product_name := pr.name;
      first_qty := (item->>'quantity')::integer;
      first_price := pr.default_price;
    end if;

    total := total + ((item->>'quantity')::numeric * pr.default_price);
    item_count := item_count + 1;
  end loop;

  select coalesce(minimum_delivery_order_amount,10000) into minimum_delivery from public.mk_settings where id=true;
  if chosen_fulfillment not in ('OFFICE_COLLECTION','DELIVERY') then raise exception 'Invalid fulfillment method'; end if;
  if total < minimum_delivery and chosen_fulfillment <> 'OFFICE_COLLECTION' then raise exception 'Orders below the minimum delivery amount must be collected at the company office'; end if;

  if p_amount_paid > total then raise exception 'Amount paid cannot exceed order total'; end if;
  if p_payment_status='PAID' and p_amount_paid < total then raise exception 'Paid status requires full payment'; end if;
  if p_payment_status='UNPAID' and p_amount_paid <> 0 then raise exception 'Unpaid status cannot have amount paid'; end if;
  if p_payment_status='PARTIAL' and (p_amount_paid <= 0 or p_amount_paid >= total) then raise exception 'Partial payment must be greater than 0 and less than total'; end if;

  select commission_rate, claim_validity_hours into rate, hours from public.mk_settings where id=true;
  sid := 'SALE-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.mk_sale_seq')::text,5,'0');

  insert into public.mk_sales(
    sale_id, advertiser_id, customer_name, customer_phone, customer_location,
    full_delivery_address, city, state, landmark,
    product_id, product_name, quantity, unit_price,
    payment_status, amount_paid, expected_collection_date, order_total, fulfillment_method
  ) values (
    sid, aid, trim(p_customer_name), trim(p_customer_phone), trim(p_customer_location),
    trim(p_full_delivery_address), trim(p_city), trim(p_state), nullif(trim(p_landmark),''),
    first_product_id, first_product_name, first_qty, first_price,
    p_payment_status, p_amount_paid, p_expected_collection_date, total, chosen_fulfillment
  ) returning * into s;

  for item in select * from jsonb_array_elements(p_items) loop
    select * into pr from public.mk_products where id=(item->>'product_id')::uuid and active=true;
    insert into public.mk_sale_items(sale_uuid,product_id,product_name,quantity,unit_price)
    values(s.id,pr.id,pr.name,(item->>'quantity')::integer,pr.default_price);
  end loop;

  code := lpad((floor(random()*900000)+100000)::int::text,6,'0');
  exp := now() + (hours || ' hours')::interval;

  insert into public.mk_authenticators(sale_uuid,code_hash,expires_at)
  values(s.id,public.mk_hash_claim_code(code),exp);

  insert into public.mk_commissions(sale_uuid,advertiser_id,rate,amount)
  values(s.id,aid,rate,round(total*rate/100,2));

  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_CLAIM_CREATED','sale',s.id::text,jsonb_build_object(
    'sale_id',sid,'advertiser_id',aid,'customer_name',s.customer_name,
    'item_count',item_count,'order_total',total,'city',s.city,'state',s.state
  ));

  return jsonb_build_object(
    'sale_id',s.sale_id,
    'authenticator_code',code,
    'total_amount',total,
    'item_count',item_count,
    'fulfillment_method',chosen_fulfillment,
    'claim_expires_at',exp
  );
end;
$$;

grant execute on function public.mk_create_sale_claim(uuid,text,text,jsonb,text,text,text,text,text,text,text,numeric,date) to authenticated;


create or replace function public.mk_verify_sale_claim(p_code text,p_customer_phone text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  a public.mk_authenticators%rowtype;
  s public.mk_sales%rowtype;
  advertiser_name text;
  items jsonb;
begin
  if not public.mk_is_admin() then raise exception 'Only staff/admin can verify claims'; end if;

  select * into a
  from public.mk_authenticators
  where code_hash=public.mk_hash_claim_code(trim(p_code)) and used_at is null
  for update;

  if not found or a.expires_at < now() then raise exception 'Invalid, expired, or used code'; end if;

  select * into s from public.mk_sales where id=a.sale_uuid for update;
  if s.status <> 'claimed' then raise exception 'This claim has already been verified, redeemed, or closed'; end if;

  if regexp_replace(s.customer_phone,'\D','','g') <> regexp_replace(trim(p_customer_phone),'\D','','g') then
    raise exception 'Customer phone does not match';
  end if;

  select full_name into advertiser_name from public.profiles where id=s.advertiser_id;
  select coalesce(jsonb_agg(jsonb_build_object(
    'product_id',i.product_id,
    'product_name',i.product_name,
    'quantity',i.quantity,
    'unit_price',i.unit_price,
    'subtotal',i.subtotal
  ) order by i.created_at),'[]'::jsonb) into items
  from public.mk_sale_items i where i.sale_uuid=s.id;

  update public.mk_sales
  set status='verified',verified_at=now(),verified_by=auth.uid()
  where id=s.id;

  insert into public.mk_audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_CLAIM_VERIFIED','sale',s.id::text,jsonb_build_object('sale_id',s.sale_id));

  return jsonb_build_object(
    'sale_id',s.sale_id,
    'advertiser_id',s.advertiser_id,
    'advertiser_name',advertiser_name,
    'customer_name',s.customer_name,
    'customer_phone',s.customer_phone,
    'full_delivery_address',s.full_delivery_address,
    'city',s.city,
    'state',s.state,
    'landmark',s.landmark,
    'customer_location',s.customer_location,
    'fulfillment_method',s.fulfillment_method,
    'items',items,
    'total_amount',s.order_total,
    'amount_paid',s.amount_paid,
    'balance',greatest(s.order_total-s.amount_paid,0),
    'payment_status',s.payment_status,
    'expected_collection_date',s.expected_collection_date,
    'status','verified'
  );
end;
$$;

grant execute on function public.mk_verify_sale_claim(text,text) to authenticated;


commit;
