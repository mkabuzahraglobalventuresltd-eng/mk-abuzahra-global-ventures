# MK Abuzahra Global Ventures Ltd — Complete System

GitHub Pages-ready static frontend for the private sales and commission management system.

## Included
- Super Admin / Admin / Staff / Advertiser access flow
- Advertiser registration and pending approval
- Sale Claim workflow
- Unique Sale ID and one-time authenticator code
- Customer verification and sale redemption
- Commission lifecycle: PENDING → ELIGIBLE → PAID
- Product management
- System settings
- Company branding/logo
- Supabase Auth + database integration
- Google Search Console verification meta tag
- `sitemap.xml` and `robots.txt`

## GitHub Pages upload
Upload the CONTENTS of this folder to the root of the `main` branch. Do not upload this ZIP as a single file, and do not create another folder around the files.

The repository root must directly contain:
- `index.html`
- `app.js`
- `styles.css`
- `config.js`
- `manifest.json`
- `sw.js`
- `sitemap.xml`
- `robots.txt`
- `assets/logo.png`
- `FINAL_SYSTEM.sql`

GitHub Pages should be set to `main` + `/(root)`.

## Supabase
The frontend uses the publishable browser key in `config.js`. Never put a Supabase secret/service-role key in this frontend.

Run `FINAL_SYSTEM.sql` in the Supabase SQL Editor once. This final SQL is designed around the current `profiles.status` / `super_admin` setup. Do not run the old chapter migration files.

## Google Search Console
The homepage contains the supplied verification tag:
`hnNDYxuEKONol5JdtUdl7gE-esqvRlX9MUyIuzwJU-8`

After this version is live, verify the exact GitHub Pages URL in Search Console using the HTML tag method, then submit:
`/mk-abuzahra-global-ventures/sitemap.xml`

## Important
GitHub Pages hosts the frontend only. Supabase remains the backend/auth/database.

## Public Advertiser Program
Open `advertiser-program.html` for the public Advertiser & Partner Program page. It is linked from the main site and included in `sitemap.xml`.

## Pricing and delivery rule update (November 2026)

This package includes `MK_Abuzahra_Pricing_Delivery_Migration.sql` and an updated `app.js`.

1. Back up the Supabase project/database before changing production.
2. In Supabase SQL Editor, run the new migration only after `FINAL_SYSTEM.sql` and `multi_item_sale_claim_update.sql` have already been applied.
3. The migration adds a default minimum delivery order amount of ₦10,000. Orders below ₦10,000 are restricted to Office Collection; orders of ₦10,000 or more may choose Delivery or Office Collection.
4. Product prices are now read from `mk_products.default_price` inside the database RPC. The browser no longer submits a price as an authority.
5. Upload the updated `app.js` to the same location in the website repository after the SQL migration succeeds.

Important: this is an incremental pricing/fulfilment update only. It does not yet implement Paystack/Monnify payments, payment webhooks, advertiser commission wallet changes, or automatic logistics booking. The website preview uses ₦10,000; the database enforces the stored threshold. The threshold is currently set by the migration default and will be made editable in the admin settings in a later step.

The migration assumes the schema in the supplied `FINAL_SYSTEM.sql` and `multi_item_sale_claim_update.sql`. It has defensive checks and will stop if required tables/columns are missing. It has not been executed against your live Supabase project from this chat.
